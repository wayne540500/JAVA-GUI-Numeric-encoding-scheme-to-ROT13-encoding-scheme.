
public class Encoder {
    public static String encodeNumeric(String s) {
        StringBuilder encoded = new StringBuilder();
        for (char c : s.toCharArray()) {
            if (Character.isLetter(c)) {
                encoded.append(c - 'a' + 1);
                encoded.append('.');
            } else if (c == ' ') {
                encoded.append(' ');
            }
        }
        return encoded.toString();
    }

    public static String encodeROT13(String s) {
        StringBuilder encoded = new StringBuilder();
        for (char c : s.toCharArray()) {
            if (Character.isLetter(c)) {
                char base = Character.isLowerCase(c) ? 'a' : 'A';
                char encodedChar = (char) (((c - base + 13) % 26) + base);
                encoded.append(encodedChar);
            } else if (c == ' ') {
                encoded.append(' ');
            }
        }
        return encoded.toString();
    }
}
