
import javax.swing.*;
import javax.swing.border.EmptyBorder;
import javax.swing.event.CaretEvent;
import javax.swing.event.CaretListener;
import javax.swing.event.DocumentEvent;
import javax.swing.event.DocumentListener;
import javax.swing.text.BadLocationException;
import javax.swing.text.Document;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;

public class EncoderInterface extends JFrame {
    private JTextArea inputArea;
    private JTextArea outputArea;
    private JFileChooser fileChooser;
    private JComboBox<String> encodingComboBox;
    private JButton clearButton;

    public EncoderInterface() {
        // Set up the GUI components
        setTitle("Text Encoder");
        setLayout(new BorderLayout());

        inputArea = new JTextArea();
        outputArea = new JTextArea();
        fileChooser = new JFileChooser(".");
        encodingComboBox = new JComboBox<>(new String[]{"Numeric Encoding", "ROT13 Encoding"});
        clearButton = new JButton("Clear");
        
        JPanel inputPanel = new JPanel(new FlowLayout(FlowLayout.LEFT));

        JPanel topPanel = new JPanel();
        topPanel.setLayout(new GridLayout(4, 1));

        // Use EmptyBorder to create wider borders for input and output areas
        int borderSize = 10; // Adjust the border size as needed
        inputArea.setBorder(new EmptyBorder(borderSize, borderSize, borderSize, borderSize));
        outputArea.setBorder(new EmptyBorder(borderSize, borderSize, borderSize, borderSize));

        // Add the combo box to the input panel
        inputPanel.add(encodingComboBox);
        // Add the "Clear" button to the input panel
        inputPanel.add(clearButton);
        
        topPanel.add(new JScrollPane(inputArea));
        //topPanel.add(encodingComboBox);
        //topPanel.add(clearButton);
        topPanel.add(inputPanel); // Add the input panel with combo box and "Clear" button

        topPanel.add(new JScrollPane(outputArea));

        add(topPanel, BorderLayout.CENTER);

        JMenuBar menuBar = new JMenuBar();
        JMenu fileMenu = new JMenu("File");
        JMenuItem openMenuItem = new JMenuItem("Open");
        JMenuItem exitMenuItem = new JMenuItem("Exit");

        openMenuItem.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                loadFile();
            }
        });

        exitMenuItem.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                System.exit(0);
            }
        });

        fileMenu.add(openMenuItem);
        fileMenu.add(exitMenuItem);
        menuBar.add(fileMenu);
        setJMenuBar(menuBar);

        inputArea.addCaretListener(new CaretListener() {
            @Override
            public void caretUpdate(CaretEvent e) {
                encodeAndDisplay();
            }
        });

        // Add a DocumentListener to monitor changes in the inputArea
        inputArea.getDocument().addDocumentListener(new DocumentListener() {
            @Override
            public void insertUpdate(DocumentEvent e) {
                encodeAndDisplay();
            }

            @Override
            public void removeUpdate(DocumentEvent e) {
                encodeAndDisplay();
            }

            @Override
            public void changedUpdate(DocumentEvent e) {
                encodeAndDisplay();
            }
        });

        encodingComboBox.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                encodeAndDisplay();
            }
        });

        clearButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                inputArea.setText("");
                outputArea.setText("");
            }
        });

        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setSize(800, 700);
        setLocationRelativeTo(null);
    }

    private void loadFile() {
        int returnValue = fileChooser.showOpenDialog(null);

        if (returnValue == JFileChooser.APPROVE_OPTION) {
            File selectedFile = fileChooser.getSelectedFile();

            try {
                BufferedReader reader = new BufferedReader(new FileReader(selectedFile));
                String line;
                StringBuilder content = new StringBuilder();

                while ((line = reader.readLine()) != null) {
                    content.append(line).append("\n");
                }

                inputArea.setText(content.toString());
                encodeAndDisplay();

            } catch (IOException e) {
                e.printStackTrace();
            }
        }
    }

    private void encodeAndDisplay() {
        String inputText = inputArea.getText();
        String selectedEncoding = (String) encodingComboBox.getSelectedItem();
        StringBuilder outputText = new StringBuilder();

        if (selectedEncoding.equals("Numeric Encoding")) {
            // Split the input text by lines
            String[] lines = inputText.split("\n");

            for (String line : lines) {
                String encodedLine = Encoder.encodeNumeric(line);
                outputText.append("Numeric Encoding:").append(encodedLine).append("\n");
            }
        } else if (selectedEncoding.equals("ROT13 Encoding")) {
            // Split the input text by lines
            String[] lines = inputText.split("\n");

            for (String line : lines) {
                String encodedLine = Encoder.encodeROT13(line);
                outputText.append("ROT13 Encoding:").append(encodedLine).append("\n");
            }
        }

        outputArea.setText(outputText.toString());
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            JFrame frame = new EncoderInterface();
            frame.setVisible(true);
        });
    }
}
